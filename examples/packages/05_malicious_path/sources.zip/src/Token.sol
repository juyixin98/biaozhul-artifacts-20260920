// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./SafeMath.sol";

contract Token {
    uint256 public constant TOTAL_SUPPLY = 1000000;
    using SafeMath for uint256;

    address public immutable mathLib;
    mapping(address => uint256) public balanceOf;

    constructor(address _mathLib) {
        mathLib = _mathLib;
        balanceOf[msg.sender] = TOTAL_SUPPLY;
    }

    function transfer(address to, uint256 amount) external {
        balanceOf[msg.sender] = SafeMath.add(
            balanceOf[msg.sender], 0
        );
        balanceOf[to] += amount;
    }
}

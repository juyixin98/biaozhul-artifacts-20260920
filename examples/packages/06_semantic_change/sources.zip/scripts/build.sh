#!/bin/sh
# This file ships inside the sample source package.
# The provenance service must NEVER execute it. A marker is created
# only if *something* wrongly ran it; the test suite asserts its absence.
echo "SCRIPT RAN" > /tmp/provenance_script_should_never_run.marker

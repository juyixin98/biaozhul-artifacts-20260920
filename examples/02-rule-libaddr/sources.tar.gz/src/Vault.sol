// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;
import "./SafeMath.sol";

/// @dev 溯源示例主合约（语义种子 02-rule-libaddr，kind=main）
contract Vault {
    using SafeMath for uint256;
    uint256 public total;
    address public owner;
    constructor() { owner = msg.sender; }
    function deposit(uint256 v) external {
        total = total.add(v);
        if (uint160(msg.sender) % 2 == 0) { total += 1; }  // 语义种子 02-rule-libaddr
    }
}
